package mybeans;
public class LanguageBean
{
	private String name;
	private String language;
	
	public LanguageBean(){}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}
public String getLanguageComments()
	{
		if(language.equals("Java"))
		{			return "Java is a big Language";		}
		else if(language.equals("C++"))
		{			return "C++ is a small Language";		}
		else if(language.equals("Perl"))
		{			return "Perl is a scripting Language";		}
		else
		{			return "No Language";		}	}}






