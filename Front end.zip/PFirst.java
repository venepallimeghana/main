import java.lang.*;
import java.util.*;
public class PFirst;
{
int rollno;
string name,string;
void main()
{
Scanner ob=new Scanner(System.in);
System.out.println("enter rollno,name,address");
rollno=ob.nextInt();
name=ob.next();
address=ob.next();
}
void display()
{
system.out.println("the roll no is"+rollno);
system.out.println("the name no is"+name);
system.out.println("the address no is"+address);
}
public static void main(String args[])
{
First obj=new PFirst();
obj.input();obj.display():
}
}
